<?php
  
  //error_reporting(0);
  $db="personalportfolio";
  $user="root";
  $pass="";
  
  try{
   $con =mysqli_connect('localhost',$user,$pass,$db);
  }catch(Exception $ex){
      echo "Eror :".$ex;
  }

?>