<?php  
  include "config.php";
  
?>


<!-- about section starts  -->

<section class="about">

    <h1 class="heading"> about <span>me</span> </h1>

    <div class="row">

        <div class="info-container">

            <h1>personal info</h1>
              <?php // for get inof from database 
                 $sql ="select * from info ";
                 $result=mysqli_query($con,$sql);
                   if($result){
                       while($row =mysqli_fetch_assoc($result)){
                         $name =$row['name']; 
                         $age  =$row['age'];
                         $skils =$row['skils'] ;
                         $email =$row['email'];
                         $address =$row['address'];
                         $experince =$row['Experience'];
                         $lang =$row['languge'];
                       }
                   }


              ?>
            <div class="box-container">

                <div class="box">
                    <h3> <span>name : </span> <?php echo $name ?> </h3>
                    <h3> <span>age : </span> <?php echo $age ?> </h3>
                    <h3> <span>email : </span> <?php echo $email ?> </h3>
                    <h3> <span>address : </span> <?php echo $address ?> </h3>
                </div>
    
                <div class="box">
                    <h3> <span>freelance : </span> available </h3>
                    <h3> <span>skill : </span> <?php echo $skils ?> </h3>
                    <h3> <span>experience : </span> <?php echo $experince ?> Years </h3>
                    <h3> <span>language : </span> <?php echo $lang ?> </h3>
                </div>

            </div>

           

        </div>

        <div class="count-container">

            <div class="box">
                <h3><?php echo $experince ?>+</h3>
                <p>years of experience</p>
            </div>

            <div class="box">
                <h3>450+</h3>
                <p>happy clients</p>
            </div>

            <div class="box">
                <h3>390+</h3>
                <p>project completed</p>
            </div>

 <!--for cookies count views-->

            <?php
$file='count.txt';
if(!file_exists($file)){
    $fopen=fopen($file,"w");
    fwrite($fopen,0);
    fclose($fopen);
}

if(!isset($_COOKIE['count'])){
    $content=file_get_contents($file);
    $val =$content+1;
    $put =file_put_contents($file,$val);
    setcookie('count',$val,time()+20*6000,"/"); ?>

    <div class="box">
                <h3><?php echo $_COOKIE['count'] ?></h3>
                <p>Number of view</p>
            </div>

  <?php }
 else ?>
<div class="box">
<h3><?php echo $_COOKIE['count']; ?></h3>
<p>Number of view</p>
</div>
 


           

        </div>

    </div>

</section>

<!-- about section ends -->

<!-- skills section starts  -->

<section class="skills">

    <h1 class="heading"> <span>my</span> skills </h1>
        <!-- for get skils from DB -->
        <div class="box-container">
     <?php
      $sql="select * from skils";
      $result=mysqli_query($con,$sql);
       if($result){
           while($row=mysqli_fetch_assoc($result)){ ?>
            
            <div class="box">
                <img src="<?php echo "images/".$row['icon'].".png"?> ">
                <h3><?php echo $row['skil'] ?></h3>
            </div>
           
            
        <?php   }
       }

    ?>
     </div>
    </section>
    
<!-- skills section ends -->

<!-- education section starts  -->

<section class="education">

    <h1 class="heading"> <span>my</span> education </h1>

    <div class="box-container">
          <?php 
             
             $sql="select * from `education`";
             $result=mysqli_query($con,$sql);
               if($result){
                   while($row=mysqli_fetch_assoc($result)){  ?>
                           
                    <div class="box">
            <i class="fas fa-graduation-cap"></i>
            <span><?php echo $row['date'] ?> </span>
            <h3><?php echo $row['subject'] ?></h3>
            <p><?php echo $row['info'] ?></p>
        </div>     

               <?php    }
               }

          ?>
    </div>

</section>

<!-- education section ends -->