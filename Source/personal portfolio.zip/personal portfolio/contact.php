<?php 
  include "config.php";

?>
<?php
  if (($_SERVER['REQUEST_METHOD']=='POST'))
    { 
     $name =$_POST['Name'];
     $phone =$_POST['phone'];
     $email =$_POST['email'];
     $subject =$_POST['subject'];
     $msg =$_POST['message'];
    // note dont forget this '' before all var in insert 
    $sql="INSERT INTO `contact` 
      VALUES ('',
      '$name',
       '$phone','$email','$subject','$msg' )";
       
       $result=mysqli_query($con,$sql);
        unset($name);
        unset( $email);
        unset( $msg);
    if ($result) {
        
		echo "<script>alert('Comment added successfully.')</script>";
    }}


?>


<!-- contact section starts  -->

<section class="contact">

<h1 class="heading"> contact <span>me</span> </h1>

<div class="row">

    <div class="info-container">

        <h1>get in touch</h1>

        <p>You accsept all condition and most do like and subscripe in our webSite and share your email in our work ?</p>
       
        <div class="box-container">
              <?php 
                   
                   $sql ="select * from info ";
                   $result =mysqli_query($con,$sql);
                     if($result){
                         while($row=mysqli_fetch_assoc($result)){ ?>

                 <div class="box">
                <i class="fas fa-map"></i>
                <div class="info">
                    <h3>address :</h3>
                    <p><?php echo $row['address'] ?></p>
                </div>
            </div>

            <div class="box">
                <i class="fas fa-envelope"></i>
                <div class="info">
                    <h3>email :</h3>
                    <p><?php echo $row['email'] ?></p>
                </div>
            </div>

            <div class="box">
                <i class="fas fa-phone"></i>
                <div class="info">
                    <h3>number :</h3>
                    <p><?php echo $row['phone'] ?></p>
                </div>
            </div>

        
                      <?php   }
                     }

             ?>
           </div>

        <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-linkedin"></a>
        </div>

    </div>

    <form action="" method="POST">

        <div class="inputBox">
            <input type="text" name ="Name" placeholder="your name" required>
            <input type="number" name="phone" placeholder="your number">
        </div>
           
        <div class="inputBox">
            <input type="email" name="email" placeholder="your email" required>
            <input type="text" name="subject" placeholder="your subject">
        </div>

        <textarea name="message" placeholder="your message" id="" cols="30" rows="10" required></textarea>

        <input type="submit" value="send message" name="submit" class="btn">

    </form>

</div>

</section>

<!-- contact section ends -->




<?php  
        $sql="SELECT * FROM `contact` ";
        $result =mysqli_query($con,$sql);
                if($result){
                    while($row=mysqli_fetch_assoc($result)){  ?>
                        <div class="comment">
                             <h3>
                         <?php echo  $row['name'];  ?>
                      <!-- <span>  <?php echo  $row['subject'];  ?></span> -->
                             </h3>
                             <p id="email">
                              <a href="mailto:<?php  echo $row['email'] ?>"><?php  echo $row['email'] ?></a>
                    </p>
                                <br>
                                <p>
                                <?php  echo $row['msg'] ?>
                             </p>
                             </div>
<?php 
             }
          }

?>

<?php  include "footer.php" ?>

