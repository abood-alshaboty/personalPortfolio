
 <?php  
 
  session_start();
  if(!isset($_SESSION['userName'])){
      header('location: index.php');
      echo "
    <script>alert('ليس لديك صلاحية')</script>;
      ";
    }
    

   else{
    
    include "config.php";
   
  
?>

<!-- home section ends -->

 
<?php 
               $sql="select * from `info`";
               $result=mysqli_query($con,$sql);
                 if($result){
                     while($row=mysqli_fetch_assoc($result)){
                     $name= $row['name'];
                     $skils =$row['skils'];
                     $image =$row['image'];
                     $note =$row['note'];
                    
                    }
                 }
                 
           ?>

 <!-- home section starts  -->

 <section class="home">
 
     <div class="image">
         <img src="<?php echo $image?>" alt="">
     </div>
 
     <div class="content">
         <h3>hi, i am <?php echo $name ?> </h3>
          <?php echo "<span>" . $skils ." </span> "?>
         <p> <?php echo $note ?></p>
         <a href="about.php" class="btn"> about me <i class="fas fa-user"></i> </a>
     </div>
      
 </section>

 
 
 <?php
 include "footer.php";

}
    
 
?>