<?php
  
 include "conDB.php";
 include "header.php"; 
 //setcookie("them","",time()+3600);
 //this code for show navbar or hide ^_^
 if (!isset($noNavbar)){
    include 'navbar.php';

}
?>