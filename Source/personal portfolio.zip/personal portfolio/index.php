

<?php 
$noNavbar ='';
include "config.php"; 

session_start();
if(isset($_SESSION['userName'])){
  header('location: home.php');
 
}else{
    



  //$result =null;
 if ($_SERVER['REQUEST_METHOD']=='POST'){
    $userName= $_POST['user'];
    $password= $_POST['pass'];
    $hashpass=md5($password);
   
    $co=0;

$sql ="SELECT userName, password FROM users where userName = '".$userName ."'  AND password =$password";
$result =mysqli_query($con,$sql);
   
   $count=mysqli_num_rows($result);
 if($count>0){
      $_SESSION['userName'] =$userName;
     
       header('location:home.php');
       //exit();
           }else {
               echo "
                <script>alert(' وزارة الدفاع  > بيانات غير صحيحة (حاذر!!!)')</script>;
                  ";
           }
           }
?>




   
<form class="login" action="" method="post">
  <img class="img-admin" src="prof.png" width="100" />
    <h4 class="text-center">Login Admin</h4><br>
    <i class="aws fa fa-user " ></i>
    <input class="form-control " type="text" name="user" placeholder="User Name" autocomplete="off" required/><br>
    <i class="aws fa fa-key" aria-hidden="true"></i>
    <input class="form-control" type="password" name="pass" placeholder="User Password" autocomplete="new-password" required/><br>
    
    <input class="btn btn-primary" type="submit" value="Login"/>
</form>



<?php 'footer.php'; ?>

          <?php }?>
