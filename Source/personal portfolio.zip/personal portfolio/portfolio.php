<?php  
  include "config.php";
?>


<!-- portfolio section starts  -->

<section class="portfolio">

    <h1 class="heading"> <span>my</span> work </h1>

    <div class="box-container">

        <div class="box">
            <img src="images/img-1.jpg" alt="">
            <div class="content">
                <h3>project 01</h3>
                <p>انتظرونا قريبا في مشاريع جديدة بإذن الله  .</p>
                <a href="#">read more</a>
            </div>
        </div>

        <div class="box">
            <img src="images/img-2.jpg" alt="">
            <div class="content">
                <h3>project 02</h3>
                <p>Comming Soon Under Devlop ..</p>
                <a href="#">read more</a>
            </div>
        </div>
       
        <div class="box">
            <img src="images/img-3.jpg" alt="">
            <div class="content">
                <h3>project 03</h3>
                <p>Comming Soon Under Devlop ..</p>
                <a href="#">read more</a>
            </div>
        </div>

        <div class="box">
            <img src="images/img-4.jpg" alt="">
            <div class="content">
                <h3>project 04</h3>
                <p>Comming Soon Under Devlop ..</p>
                <a href="#">read more</a>
            </div>
        </div>

        <div class="box">
            <img src="images/img-5.jpg" alt="">
            <div class="content">
                <h3>project 05</h3>
                <p>Comming Soon Under Devlop .</p>
                <a href="#">read more</a>
            </div>
        </div>

        <div class="box">
            <img src="images/img-6.jpg" alt="">
            <div class="content">
                <h3>project 06</h3>
                <p>Comming Soon Under Devlop ..</p>
                <a href="#">read more</a>
            </div>
        </div>

    </div>

    <a href="#" class="btn"> load more <i class="fas fa-redo"></i> </a>
    
</section>

<!-- portfolio section ends -->