<?php
  include "config.php";
 
?>

<!-- blogs section starts  -->

<section class="blogs">

    <h1 class="heading"> <span>my</span> blogs </h1>

    <div class="box-container">

         <?php 
               
             $sql="select * from blogs";
             $result =mysqli_query($con,$sql);
                if($result){
                    while($row=mysqli_fetch_assoc($result)){  ?>
                        <div class="box">
                        <div class="image">
                            <img src="<?php echo $row['image'].".jpg" ?>" alt="">
                        </div>
                        <div class="content">
                            <div class="icons">
                                <a href="#"> <i class="fas fa-calendar"></i> <?php echo $row['date'] ?> </a>
                                <a href="#"> <i class="fas fa-user"></i> <?php echo $row['writer'] ?> </a>
                            </div>
                            <h3><?php echo $row['title'] ?>.</h3>
                            <p><?php echo $row['simple'] ?>.</p>
                            <a href="blog-post.php" class="btn"> read more <i class="fas fa-link"></i> </a>
                        </div>
                    </div>
                <?php    }
                }

         ?>

       

    </div>

</section>

<!-- blogs section ends -->