<?php
include 'config.php';
?>
       
       <?php 
            $sql="select * from blogs where id =3";
             $result =mysqli_query($con,$sql);
                if($result){
                    while($row=mysqli_fetch_assoc($result)) {  ?>
                        <div class="box-post">
                        <h2 id="details"> Details</h2>
                        <div class="image">

                            <img src="<?php echo $row['image'].".jpg" ?>" alt="">
                            </div>
                            <h1><?php echo $row['title']?></h1>
                            
                            <p><?php echo $row['post']?></p>
                           
                            <p id="writer"> <i class="icon-writer fas fa-user"></i><?php echo $row['writer']?></p>
                            <a href="blogs.php" class="back btn"> Go To Back  <i class="fas fa-link"></i> </a>
                        </div>
                     
                    <?php }} ?>

                   
                    