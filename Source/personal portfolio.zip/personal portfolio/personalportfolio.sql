-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 15 أكتوبر 2022 الساعة 22:02
-- إصدار الخادم: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `personalportfolio`
--

-- --------------------------------------------------------

--
-- بنية الجدول `blogs`
--

CREATE TABLE `blogs` (
  `id` int(3) NOT NULL,
  `title` varchar(50) NOT NULL,
  `date` datetime NOT NULL,
  `writer` varchar(30) NOT NULL,
  `simple` varchar(100) NOT NULL,
  `post` text NOT NULL,
  `image` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `blogs`
--

INSERT INTO `blogs` (`id`, `title`, `date`, `writer`, `simple`, `post`, `image`) VALUES
(1, 'PHP Tutorial', '2022-01-24 23:33:48', 'abood', 'PHP is an amazing and popular language!', 'It is powerful enough to be at the core of the biggest blogging system on the web (WordPress)!\r\nIt is deep enough to run the largest social network (Facebook)!\r\nIt is also easy enough to be a beginner\'s first server side language!\r\nWhat Can PHP Do?\r\nPHP can generate dynamic page content\r\nPHP can create, open, read, write, delete, and close files on the server\r\nPHP can collect form data\r\nPHP can send and receive cookies\r\nPHP can add, delete, modify data in your database\r\nPHP can be used to control user-access\r\nPHP can encrypt data\r\nWith PHP you are not limited to output HTML. You can output images, PDF files, and even Flash movies. You can also output any text, such as XHTML and XML.\r\n\r\n\r\n', 'images/blog1'),
(2, 'Ho is Abood', '2022-01-24 23:43:29', 'abdulrahman', 'abood is programer in yemen is smart and blblabla\r\n', 'hello evry one here i love  languge program and web design \r\ni live in yeme-taiz\r\nmy address is alsaha street and i like trival and alot things good private ', 'images/user'),
(3, 'شهادة شكر وعرفان ', '2022-02-22 19:59:32', 'eng.abood', 'انه يشكر نفسة بنفسة ياااهلا والله 😍😊😘\r\n', 'What is Lorem Ipsum?\r\nLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'images/img-1');

-- --------------------------------------------------------

--
-- بنية الجدول `contact`
--

CREATE TABLE `contact` (
  `id` int(3) NOT NULL,
  `name` varchar(40) NOT NULL,
  `phone` int(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `msg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `contact`
--

INSERT INTO `contact` (`id`, `name`, `phone`, `email`, `subject`, `msg`) VALUES
(140, 'abood', 775, 'admin@gmail.com', 'thanks', 'تسلم حبيب الشعب عبود'),
(148, 'anynumos', 0, '', '', 'thanks admin i love you'),
(149, 'aden ', 0, 'dd@gmail.com', '', 'thanks for all '),
(173, 'tester', 0, 'abooddevlop@gmail.com', 'Succssfle', 'all is good'),
(177, '❤', 0, 'abood-devlop@gmail.com', '', '😍😂😍😍😍😍😍😍😍😍'),
(180, 'afnan', 0, 'abood-devlop@gmail.com', 'test', 'thanks '),
(181, 'abood alshaboty', 0, 'almqtry688@gmail.com', '', 'thanks');

-- --------------------------------------------------------

--
-- بنية الجدول `education`
--

CREATE TABLE `education` (
  `id` int(2) NOT NULL,
  `date` varchar(20) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `info` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `education`
--

INSERT INTO `education` (`id`, `date`, `subject`, `info`) VALUES
(1, '2020 -2021', 'Front-End Development', 'studied at the University of Jund and got an excellent appreciation and was an interesting study'),
(2, '2022 ', 'Back-End Development', 'studied at the University of Jund and got an excellent appreciation and was an interesting study');

-- --------------------------------------------------------

--
-- بنية الجدول `info`
--

CREATE TABLE `info` (
  `id` int(2) NOT NULL,
  `name` varchar(50) NOT NULL,
  `skils` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `address` varchar(100) NOT NULL,
  `phone` int(15) NOT NULL,
  `age` int(3) NOT NULL,
  `Experience` int(2) NOT NULL,
  `languge` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `info`
--

INSERT INTO `info` (`id`, `name`, `skils`, `email`, `address`, `phone`, `age`, `Experience`, `languge`, `image`, `note`) VALUES
(1, 'abdulrahman Tawfeek Alshaboty', 'Full stack Devloper', 'taiz3154@gmail.com', 'taiz yemen ', 775839090, 20, 1, 'Arabic.English', '	 images/user.jpg', 'welcome evry one \r\nthis webSite Design by abood alshaboty \r\nfor Project en.Afnan Alkhorsani in php course in jand unvirsity \r\n\r\nour lover abood \r\ni live in yemne i wont to trival to Turkey complete Studes mstr \r\nof allh wils ...');

-- --------------------------------------------------------

--
-- بنية الجدول `skils`
--

CREATE TABLE `skils` (
  `id` int(2) NOT NULL,
  `skil` varchar(50) NOT NULL,
  `icon` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `skils`
--

INSERT INTO `skils` (`id`, `skil`, `icon`) VALUES
(1, 'HTML', 'icon-1'),
(2, 'CSS', 'icon-2'),
(3, 'PHP', 'icon-3'),
(4, 'Bootstap', 'icon-4'),
(5, 'Java', 'icon-5');

-- --------------------------------------------------------

--
-- بنية الجدول `user`
--

CREATE TABLE `user` (
  `id` int(2) NOT NULL,
  `name` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `user`
--

INSERT INTO `user` (`id`, `name`, `password`) VALUES
(1, 'abdulrahman Tawfeek Alshaboty', 'abood');

-- --------------------------------------------------------

--
-- بنية الجدول `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `userName` varchar(50) NOT NULL,
  `password` varchar(32) CHARACTER SET macce COLLATE macce_bin NOT NULL,
  `groupId` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `users`
--

INSERT INTO `users` (`id`, `userName`, `password`, `groupId`) VALUES
(1, 'abood', '1122', 1),
(2, 'sadiq', '1122', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `education`
--
ALTER TABLE `education`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skils`
--
ALTER TABLE `skils`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=182;

--
-- AUTO_INCREMENT for table `education`
--
ALTER TABLE `education`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `skils`
--
ALTER TABLE `skils`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
